import logging
import os
import sqlite3
from pathlib import Path

from telegram import Update
from telegram.error import TelegramError
from telegram.ext import Application, CommandHandler, ContextTypes


logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

PRODUCTS = {
    "1": {"name": "Gói dịch vụ A", "price": 20_000},
    "2": {"name": "File số B", "price": 50_000},
}

DB_PATH = Path(os.getenv("SHOP_DB_PATH", "shop.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
db = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute("PRAGMA journal_mode=WAL")
db.execute("PRAGMA busy_timeout=10000")


def initialize_database():
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending'
        )
        """
    )

    # Additive migration keeps existing shop.db orders intact.
    columns = {
        row["name"] for row in db.execute("PRAGMA table_info(orders)").fetchall()
    }
    migrations = {
        "product_name": "TEXT NOT NULL DEFAULT ''",
        "amount": "INTEGER NOT NULL DEFAULT 0",
        "created_at": "TEXT NOT NULL DEFAULT ''",
        "payment_reported_at": "TEXT",
        "paid_at": "TEXT",
        "delivered_at": "TEXT",
    }
    for column, definition in migrations.items():
        if column not in columns:
            db.execute(f"ALTER TABLE orders ADD COLUMN {column} {definition}")

    db.execute(
        "UPDATE orders SET created_at = CURRENT_TIMESTAMP WHERE created_at = ''"
    )
    # Backfill old orders when their product is still present in the catalog.
    for product_id, product in PRODUCTS.items():
        db.execute(
            """
            UPDATE orders
            SET product_name = ?, amount = ?
            WHERE product_id = ? AND (product_name = '' OR amount = 0)
            """,
            (product["name"], product["price"], product_id),
        )
    db.commit()


initialize_database()


def money(value: int) -> str:
    return f"{value:,}".replace(",", ".") + "đ"


def get_admin_id() -> int:
    raw_value = os.getenv("ADMIN_ID", "").strip()
    try:
        return int(raw_value)
    except ValueError as exc:
        raise RuntimeError("Thiếu ADMIN_ID hợp lệ trong biến môi trường.") from exc


def get_order(order_id: int):
    return db.execute(
        "SELECT * FROM orders WHERE id = ?", (order_id,)
    ).fetchone()


async def notify_admin(context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    try:
        await context.bot.send_message(chat_id=context.bot_data["admin_id"], text=text)
        return True
    except TelegramError:
        logger.exception("Could not send an admin notification")
        return False


def parse_order_id(context: ContextTypes.DEFAULT_TYPE):
    if not context.args or not context.args[0].isdigit():
        return None
    return int(context.args[0])


def display_product(order) -> str:
    return order["product_name"] or f"Mã {order['product_id']}"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "🛍 NKHANG SHOP\n\n"
        "/products — Xem sản phẩm\n"
        "/buy 1 — Mua sản phẩm mã 1\n"
        "/paid 1 — Báo đã chuyển khoản cho đơn 1\n\n"
        "Shop xác nhận tiền thủ công; báo đã chuyển khoản không đồng nghĩa "
        "đơn đã được thanh toán."
    )


async def products(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = ["📦 DANH SÁCH SẢN PHẨM\n"]
    for product_id, product in PRODUCTS.items():
        lines.append(
            f"Mã {product_id}: {product['name']} — {money(product['price'])}"
        )
    lines.append("\nMua bằng lệnh: /buy MÃ_SẢN_PHẨM")
    await update.effective_message.reply_text("\n".join(lines))


async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or context.args[0] not in PRODUCTS:
        await update.effective_message.reply_text(
            "Mã sản phẩm không hợp lệ. Dùng /products để xem danh sách."
        )
        return

    product_id = context.args[0]
    product = PRODUCTS[product_id]
    cursor = db.execute(
        """
        INSERT INTO orders (user_id, product_id, product_name, amount)
        VALUES (?, ?, ?, ?)
        """,
        (
            update.effective_user.id,
            product_id,
            product["name"],
            product["price"],
        ),
    )
    db.commit()
    order_id = cursor.lastrowid

    bank_name = os.getenv("BANK_NAME", "TEN_NGAN_HANG")
    bank_account = os.getenv("BANK_ACCOUNT", "SO_TAI_KHOAN")
    bank_owner = os.getenv("BANK_OWNER", "TEN_CHU_TAI_KHOAN")
    await update.effective_message.reply_text(
        f"🧾 ĐƠN HÀNG #{order_id}\n"
        f"Sản phẩm: {product['name']}\n"
        f"Số tiền: {money(product['price'])}\n\n"
        f"🏦 Ngân hàng: {bank_name}\n"
        f"Số tài khoản: {bank_account}\n"
        f"Chủ tài khoản: {bank_owner}\n"
        f"Nội dung chuyển khoản: NK{order_id}\n\n"
        f"Sau khi chuyển khoản, gửi /paid {order_id}.\n"
        "Chỉ admin mới xác nhận thanh toán sau khi kiểm tra tài khoản ngân hàng."
    )

    user = update.effective_user
    notified = await notify_admin(
        context,
        f"🛒 Đơn mới #{order_id}\n"
        f"Khách: {user.full_name} (ID {user.id})\n"
        f"Sản phẩm: {product['name']}\n"
        f"Số tiền: {money(product['price'])}",
    )
    if not notified:
        await update.effective_message.reply_text(
            "Đơn đã được lưu, nhưng shop chưa nhận được thông báo tự động. "
            "Vui lòng liên hệ shop và cung cấp mã đơn."
        )


async def paid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    order_id = parse_order_id(context)
    if order_id is None:
        await update.effective_message.reply_text("Cú pháp: /paid MÃ_ĐƠN")
        return

    order = get_order(order_id)
    if not order or order["user_id"] != update.effective_user.id:
        await update.effective_message.reply_text("Không tìm thấy đơn hàng của bạn.")
        return
    if order["status"] == "delivered":
        await update.effective_message.reply_text("Đơn này đã được giao.")
        return
    if order["status"] in ("paid", "delivering"):
        await update.effective_message.reply_text(
            "Shop đã xác nhận thanh toán cho đơn này."
        )
        return
    if order["status"] == "payment_reported":
        await update.effective_message.reply_text(
            "Shop đã nhận báo cáo chuyển khoản. Vui lòng chờ kiểm tra."
        )
        return

    cursor = db.execute(
        """
        UPDATE orders
        SET status = 'payment_reported', payment_reported_at = CURRENT_TIMESTAMP
        WHERE id = ? AND user_id = ? AND status = 'pending'
        """,
        (order_id, update.effective_user.id),
    )
    db.commit()
    if cursor.rowcount != 1:
        await update.effective_message.reply_text(
            "Trạng thái đơn vừa thay đổi. Vui lòng kiểm tra lại với shop."
        )
        return

    user = update.effective_user
    notified = await notify_admin(
        context,
        f"💰 Khách báo đã chuyển khoản đơn #{order_id}.\n"
        f"Khách: {user.full_name} (ID {user.id})\n"
        f"Kiểm tra giao dịch thực tế trước khi xác nhận thanh toán.",
    )
    if notified:
        await update.effective_message.reply_text(
            "Shop đã nhận thông báo. Đơn chỉ được xác nhận sau khi shop "
            "kiểm tra giao dịch thực tế."
        )
    else:
        await update.effective_message.reply_text(
            "Báo cáo đã được lưu nhưng shop chưa nhận được thông báo tự động. "
            "Vui lòng liên hệ shop và cung cấp mã đơn."
        )


async def confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != context.bot_data["admin_id"]:
        await update.effective_message.reply_text("Bạn không có quyền dùng lệnh này.")
        return

    order_id = parse_order_id(context)
    if order_id is None:
        await update.effective_message.reply_text(
            "Cú pháp: /confirm MÃ_ĐƠN — chỉ dùng sau khi kiểm tra tiền đã vào."
        )
        return

    order = get_order(order_id)
    if not order:
        await update.effective_message.reply_text("Không tìm thấy đơn.")
        return
    if order["status"] == "delivered":
        await update.effective_message.reply_text("Đơn này đã được giao.")
        return
    if order["status"] == "delivering":
        await update.effective_message.reply_text(
            "Đơn đang được gửi; không xác nhận lại."
        )
        return
    if order["status"] == "paid":
        await update.effective_message.reply_text(
            "Đơn đã được xác nhận thanh toán."
        )
        return

    cursor = db.execute(
        """
        UPDATE orders SET status = 'paid', paid_at = CURRENT_TIMESTAMP
        WHERE id = ? AND status IN ('pending', 'payment_reported')
        """,
        (order_id,),
    )
    db.commit()
    if cursor.rowcount != 1:
        await update.effective_message.reply_text(
            "Trạng thái đơn vừa thay đổi. Kiểm tra lại trước khi tiếp tục."
        )
        return

    await update.effective_message.reply_text(
        f"Đã xác nhận đơn #{order_id}. Dùng /deliver {order_id} Nội_dung_giao_hàng "
        "để giao hàng."
    )
    try:
        await context.bot.send_message(
            chat_id=order["user_id"],
            text=f"✅ Shop đã xác nhận thanh toán cho đơn #{order_id}.",
        )
    except TelegramError:
        logger.exception("Could not notify customer that payment was confirmed")


async def deliver(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != context.bot_data["admin_id"]:
        await update.effective_message.reply_text("Bạn không có quyền dùng lệnh này.")
        return

    order_id = parse_order_id(context)
    if order_id is None or len(context.args) < 2:
        await update.effective_message.reply_text(
            "Cú pháp: /deliver MÃ_ĐƠN Nội_dung_giao_hàng"
        )
        return

    content = " ".join(context.args[1:]).strip()
    if not content:
        await update.effective_message.reply_text("Nội dung giao hàng không được trống.")
        return
    if len(content) > 3500:
        await update.effective_message.reply_text(
            "Nội dung quá dài (tối đa 3500 ký tự mỗi lần gửi)."
        )
        return

    order = get_order(order_id)
    if not order:
        await update.effective_message.reply_text("Không tìm thấy đơn.")
        return
    if order["status"] == "delivered":
        await update.effective_message.reply_text("Đơn này đã được giao.")
        return
    if order["status"] != "paid":
        await update.effective_message.reply_text(
            "Chưa thể giao: hãy kiểm tra tiền vào rồi dùng /confirm MÃ_ĐƠN trước."
        )
        return

    # Claim atomically so two simultaneous /deliver commands cannot both send.
    cursor = db.execute(
        "UPDATE orders SET status = 'delivering' WHERE id = ? AND status = 'paid'",
        (order_id,),
    )
    db.commit()
    if cursor.rowcount != 1:
        await update.effective_message.reply_text(
            "Đơn vừa được xử lý ở nơi khác; hãy kiểm tra trạng thái."
        )
        return

    try:
        await context.bot.send_message(
            chat_id=order["user_id"],
            text=f"✅ Đơn #{order_id} — Nội dung giao hàng:\n{content}",
        )
    except TelegramError:
        logger.exception("Could not deliver order %s", order_id)
        db.execute(
            "UPDATE orders SET status = 'paid' WHERE id = ? AND status = 'delivering'",
            (order_id,),
        )
        db.commit()
        await update.effective_message.reply_text(
            "Không gửi được cho khách; đơn vẫn được giữ ở trạng thái đã thanh toán. "
            "Khách cần mở bot và nhấn Start trước khi thử lại."
        )
        return

    db.execute(
        """
        UPDATE orders
        SET status = 'delivered', delivered_at = CURRENT_TIMESTAMP
        WHERE id = ? AND status = 'delivering'
        """,
        (order_id,),
    )
    db.commit()
    await update.effective_message.reply_text(f"Đã gửi hàng cho đơn #{order_id}.")


def main():
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("Thiếu BOT_TOKEN trong biến môi trường.")

    admin_id = get_admin_id()
    app = Application.builder().token(token).build()
    app.bot_data["admin_id"] = admin_id
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("products", products))
    app.add_handler(CommandHandler("buy", buy))
    app.add_handler(CommandHandler("paid", paid))
    app.add_handler(CommandHandler("confirm", confirm))
    app.add_handler(CommandHandler("deliver", deliver))
    logger.info("Shop bot is starting")
    app.run_polling()


if __name__ == "__main__":
    main()
