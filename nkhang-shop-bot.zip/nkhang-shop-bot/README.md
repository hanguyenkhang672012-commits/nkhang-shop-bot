# NKHANG SHOP Telegram bot

Python Telegram bot for a small digital shop. It supports `/start`, `/products`, `/buy`, `/paid`, `/confirm`, and `/deliver`.

## Required environment variables

Set these in the hosting provider's environment variables/secrets panel:

- `BOT_TOKEN`: token from Telegram's `@BotFather`
- `ADMIN_ID`: your numeric Telegram user ID
- `BANK_NAME`: bank name shown to customers
- `BANK_ACCOUNT`: receiving account number
- `BANK_OWNER`: account holder name
- `SHOP_DB_PATH` (optional): path for the SQLite database, default `shop.db`

Do not commit real tokens or bank credentials to GitHub. `BANK_NAME`, `BANK_ACCOUNT`, and `BANK_OWNER` can be left unset while testing; the bot will show placeholders.

## Run

Install requirements and run `python main.py`.

## Important

Edit the `PRODUCTS` dictionary in `main.py` to use your real product names/prices. The bot does not verify bank transfers automatically: an admin must verify funds and then use `/confirm ORDER_ID` before delivering with `/deliver ORDER_ID message`.

SQLite data can be lost if the host replaces ephemeral storage; use persistent storage if the hosting provider offers it.
